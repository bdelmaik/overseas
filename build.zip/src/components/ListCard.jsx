import React from 'react'
import styles from "./components/listCard.module.css";

export default function ListCard() {
  return (
    <div className={styles.listCard}>
        
    </div>
  )
}
