import React from 'react'
import styles from "../components/footer.module.css";

export default function FooterAll() {
  return (
    <div>
    <div className={styles.footer}>
        <div>
           <a href="">Enlace</a>
        </div>
        <div>
           <a href="">Enlace</a>
        </div>
        <div>
            <input type="email" name="" id="" />
        </div>
    </div>
    </div>
  )
}
